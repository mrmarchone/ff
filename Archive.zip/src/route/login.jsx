import React, {Component} from 'react';
// import sha1 from 'js-sha1';
import sha256 from 'sha256';
class Login extends Component {
    render () {
        return (
            <div>
                Login
                {console.log(sha256(Date('h:s:i'), { asString: true }))}
            </div>
        )
    }
}



export default Login;