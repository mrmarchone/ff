import React, {Component} from 'react';

class Signup extends Component {
    render () {
        return (
            <div>
                Signup
            </div>
        )
    }
}



export default Signup;