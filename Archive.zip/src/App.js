import React, { Component } from 'react';
import Nav from './component/Nav';
import {BrowserRouter, Route} from 'react-router-dom';
import Login from './route/login';
import Signup from './route/signup';
class App extends Component {
  render() {
    return (
      <div className="App">
        <BrowserRouter>
        <div>
        <Nav />
        <Route exact path='/' />
        <Route path='/login'  component={Login} />
        <Route path='/signup' component={Signup} />
        asdasd
        </div>
        </BrowserRouter>
      </div>
    );
  }
}

export default App;
